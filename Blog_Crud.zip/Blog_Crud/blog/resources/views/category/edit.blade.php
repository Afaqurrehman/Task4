<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="stylesheet" href="{{asset('assets\assets/css/bootstrap.min.css') }}">
</head>
<body>
 
    <div class="bg-dark py3"> 
        <div class="container">
            <div class="h4 text-white">Edit categories </div>
</div>
    </div>
    <div class="container">
        <div class="d-flex justify-content-between py-3">
            <div class="h4">Edit</div>
            <div>
                <a href="{{route('category.index')}}" class="btn btn-primary">Back</a>
               </div>
            </div>
        <form action="{{route('category.update',$category->id)}}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('put')

            <div class="card border-0 shadow-lg">
                <div class="card-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Category Name</label>
                        <input type="text" name="categoryname" id="categoryname" placeholder="Enter title of book" class="form-control
                        @error('title') is-invalid @enderror" value="{{old('title',$category->categoryname)}}">
                        @error('title') 
                        <p class="invalid-feedback">{{$message}}</p>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="author" class="form-label">Description</label>
                        <input type="text" name="description" id="description" placeholder="Enter author name" class="form-control
                        @error('author') is-invalid @enderror" value="{{old('title',$category->description)}}">
                        @error('author')
                        <p class="invalid-feedback">{{$message}}</p>
                        @enderror
                    </div>
                </div>
            </div>
            <button class="btn btn-primary my-3">update categoty</button>
        </form>
    </div>
</body>
</html>