<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blogs</title>
    <link rel="stylesheet" href="{{asset('assets\assets/css/bootstrap.min.css') }}">
</head>
<body>
 
    <div class="bg-dark py3"> 
        <div class="container">
            <div class="h4 text-white">Blogs </div>
</div>
    </div>
    <div class="container">
        <div class="d-flex justify-content-between py-3">
            <div class="h4">Add new categories</div>
            <div>
                <a href="{{route('category.create')}}" class="btn btn-primary">Add</a>
                <a href="{{route('post.index')}}" class="btn btn-secondary">Post Page</a>
               </div>
            </div>
            @if(Session::has('success'))
            <div class="alert alert-success">
              {{Session::get('success')}}
            </div>
            @endif
        <div class="card border-0 shadow-lg">
            <div class="card-body">
                <table class="table table-striped">
                    <tr>
                        <th>category name</th>
                        <th>description</th>
                    </tr>
                    @if($category->isNotEmpty())
                    @foreach($category as $category)
                    <tr valign="middle">
                        <td>{{ $category->categoryname}}</td>
                        <td>{{ $category->description}}</td>
                    <td>
                        <a href="{{route('category.edit',$category->id)}}" class="btn btn-primary btn-sm"> Edit </a>
                    </td>
                    <td>
                        <a href="/delete/category/{{$category->id}}" class="btn btn-danger btn-sm">Delete</a>

                    </td>
                    <td>
                        <a href="{{route('post.getpost',$category->id)}}" class="btn btn-secondary btn-sm"> Post </a>

                    </td>
                    </tr>
                    @endforeach
                    @else
                    <tr>
                        <td colspan="6">Record not found</tr>
                    @endif

                    
</table>
            </div>
        </div>
    </div>
</body>
</html>