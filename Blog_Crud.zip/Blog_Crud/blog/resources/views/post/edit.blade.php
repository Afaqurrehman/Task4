<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="stylesheet" href="{{asset('assets\assets/css/bootstrap.min.css') }}">
</head>
<body>
 
    <div class="bg-dark py3"> 
        <div class="container">
            <div class="h4 text-white">Edit Post </div>
</div>
    </div>
    <div class="container">
        <div class="d-flex justify-content-between py-3">
            <div class="h4">Edit</div>
            <div>
                <a href="{{route('post.index')}}" class="btn btn-primary">Back</a>
               </div>
            </div>
        <form action="{{route('post.update',$post->id)}}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('put')

            <div class="card border-0 shadow-lg">
                <div class="card-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Post Title</label>
                        <input type="text" name="posttitle" id="posttitle" placeholder="Enter title of book" class="form-control
                        @error('title') is-invalid @enderror" value="{{old('title',$post->posttitle)}}">
                        @error('title') 
                        <p class="invalid-feedback">{{$message}}</p>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="author" class="form-label">Content</label>
                        <input type="text" name="content" id="content" placeholder="Enter author name" class="form-control
                        @error('author') is-invalid @enderror" value="{{old('title',$post->content)}}">
                        @error('author')
                        <p class="invalid-feedback">{{$message}}</p>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="author" class="form-label">Publication Date</label>
                        <input type="text" name="publicationdate" id="publicationdate" placeholder="Enter author name" class="form-control
                        @error('author') is-invalid @enderror" value="{{old('title',$post->publicationdate)}}">
                        @error('author')
                        <p class="invalid-feedback">{{$message}}</p>
                        @enderror
                    </div>
                </div>
            </div>
            <button class="btn btn-primary my-3">update Post</button>
        </form>
    </div>
</body>
</html>