<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Category;
use Illuminate\Support\Validator;

class PostController extends Controller
{
    public function index(){

        $post = Post::orderBy('id','DESC')->get();
       return view('post.index',['post'=> $post]);
    }

    public function create(){
        $category_id = Category::all();
        return view('post.create',['category'=>$category_id]);
    }

    public function store(Request $request){
        
        $post = new Post();
        $post->posttitle = request("posttitle");
        $post->content =  request("content");
        $post->publicationdate =  request("publicationdate");
        $post->category_id =  request("category_id");
        $post->save();
         
        $request->session()->flash('success','Employee added successfully');

        return redirect()->route('post.index');

       
    
    }
    public function edit($id){
        $post = Post::findOrFail($id);
        return view('post.edit',['post'=>$post]);
    }

    public function update($id, Request $request){
        $post = Post::find($id);
        $post->posttitle = request("posttitle");
        $post->content =  request("content");
        $post->publicationdate =  request("publicationdate");
        $post->save();
         
        $request->session()->flash('success','Employee added successfully');

        return redirect()->route('post.index',$post->id);

    }

    public function destroy($id, Request $request){
      $post = Post::find($id);
      $post->delete();

      return redirect()->route('post.index');

    }
    public function getpost($category_id){
      $getpost = Post::where('category_id',$category_id)->get();
        return view('post.getpost',['post'=>$getpost]);
    }
}
