<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Validator;
use App\Models\Category;

class CategoryController extends Controller
{
    public function index(){

        $category = Category::orderBy('id','DESC')->get();
       return view('category.index',['category'=> $category]);
    }

    public function create(){
        return view('category.create');
    }

    public function store(Request $request){
        
        $category = new Category();
        $category->categoryname = request("categoryname");
        $category->description =  request("description");
        $category->save();
         
        $request->session()->flash('success','Employee added successfully');

        return redirect()->route('category.index');

       
    
    }
    public function edit($id){
        $category = Category::findOrFail($id);
        return view('category.edit',['category'=>$category]);
    }

    public function update($id, Request $request){
        $category = Category::find($id);
        $category->categoryname = request("categoryname");
        $category->description =  request("description");
        $category->save();
         
        $request->session()->flash('success','Employee added successfully');

        return redirect()->route('category.index',$category->id);

    }

    public function destroy($id, Request $request){
      $category = Category::find($id);
      $category->delete();

      return redirect()->route('category.index');

    }
}
