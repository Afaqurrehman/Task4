<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Related Post</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets\assets/css/bootstrap.min.css')); ?>">
</head>
<body>
 
    <div class="bg-dark py3"> 
        <div class="container">
            <div class="h4 text-white">Post</div>
</div>
    </div>
    <div class="container">
        <div class="d-flex justify-content-between py-3">
            <div class="h4">Related Posts</div>
            <div>
                <a href="<?php echo e(route('post.index')); ?>" class="btn btn-primary">Back</a>
               </div>
            </div>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>
        <div class="card border-0 shadow-lg">
            <div class="card-body">
                <table class="table table-striped">
                    <tr>
                        <th>Post Title</th>
                        <th>Content</th>
                        <th>Publication Date</th>
                    </tr>
                    <?php if($post->isNotEmpty()): ?>
                    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr valign="middle">
                        <td><?php echo e($post->posttitle); ?></td>
                        <td><?php echo e($post->content); ?></td>
                        <td><?php echo e($post->publicationdate); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="6">Record not found</tr>
                    <?php endif; ?>

                    
</table>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\AFAQ UR REHMAN\Desktop\Blog_Crud\blog\resources\views/post/getpost.blade.php ENDPATH**/ ?>